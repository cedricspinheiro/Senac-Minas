
expressao = input('Escreva uma expressão: ')
empatia = expressao
if expressao == empatia:
    print('É palíndromo, pois, {} --> {}.'.format(expressao, empatia))
else:
    print('Não é palíndromo.')
from tkinter import *

janela = Tk()
janela.title('Calculo de Salario')

horas = Label(janela, text='Horas Trabalhadas:', anchor='e')
horas.grid(row=0, column=0, sticky='we')
valor = Label(janela, text='Valor da Hora:', anchor='e')
valor.grid(row=1, column=0, sticky='we')

ehora = Entry(janela)
ehora.grid(row=0, column=1)
evalor = Entry(janela)
evalor.grid(row=1, column=1)

botao = Button(janela, text='Calcular')
botao.grid(row=1, column=2, sticky='we')

barra = Label(janela, text='=============================================')
barra.grid(row=2, column=0, columnspan=3)

salariob = Label(janela, text='+ Salario Bruto: R$')
salariob.grid(row=3, column=0)

janela.mainloop()

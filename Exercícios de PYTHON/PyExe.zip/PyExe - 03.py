# Faça um Programa que peça dois números e imprima a soma.

print('Soma de dois numeros')
n1 = int(input('Informe o primeiro numero: '))
n2 = int(input('Informe o segundo numero: '))
print('A soma dos numeros são: (', n1 + n2,')')
# Tendo como dados de entrada a altura de uma pessoa, construa um algoritmo que calcule seu
# peso ideal, usando a seguinte fórmula: (72.7*altura) - 58

altura = float(input('Diga sua altura: '))
peso_ideal = (72.7 * altura) - 58
print('Sua o peso ideal para sua altura (',altura,') é de: (',peso_ideal,'Kg)')
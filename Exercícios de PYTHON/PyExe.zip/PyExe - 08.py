# Faça um Programa que pergunte quanto você ganha por hora e o número de horas
# trabalhadas no mês. Calcule e mostre o total do seu salário no referido mês.

salario_hora = float(input('Quanto você ganha por hora? '))
hora_mensal = float(input('Quantas horas trabalhadas no mês? '))
print('O valor a receber é de',salario_hora * hora_mensal)
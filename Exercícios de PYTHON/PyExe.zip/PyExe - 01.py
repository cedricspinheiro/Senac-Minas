# Faça um Programa que mostre a mensagem "Olá mundo!" na tela.

print('Olá mundo!')
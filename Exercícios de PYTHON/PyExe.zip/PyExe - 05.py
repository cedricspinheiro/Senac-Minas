# Faça um Programa que converta metros para centímetros.

print('Converção de M pra cm')
cm = float(input('Digite a metragem: '))
print('O cm da metragem é de: (', cm * 100,')')
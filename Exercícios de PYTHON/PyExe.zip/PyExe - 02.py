# Faça um Programa que peça um número e então mostre a mensagem O número informado foi [número].

n = int(input('Digite um numero: '))
print('O numero informado foi (',n,')')